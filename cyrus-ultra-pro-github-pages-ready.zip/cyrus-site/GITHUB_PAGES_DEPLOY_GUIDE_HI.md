# Cyrus Ultra Pro — GitHub Pages deployment (Hindi)

## Upload
1. ZIP ko extract karo. Andar `cyrus-site` folder hai.
2. GitHub repository `cyrus-ultra-pro-real-api` mein project files/folders upload karo; repository root par `package.json`, `package-lock.json`, `index.html`, `src/`, `vite.config.ts` aur `.github/` hone chahiye. `cyrus-site` folder ko nested folder ke roop mein upload mat karna.
3. Existing files ko replace karne se pehle backup rakhna.
4. `.github/workflows/deploy-pages.yml` workflow `main` branch push par automatically run hoga.
5. GitHub repository → Settings → Pages → Build and deployment → Source mein **GitHub Actions** select hona chahiye.
6. Actions tab mein workflow ka green tick aane ka wait karo. Settings → Pages par published URL milega.

## Important limitation
Yeh workflow Vite/React **frontend** build karta hai. `server.ts` wala Node.js/Express backend GitHub Pages par run nahi hota. Agar app ko apne `/api` backend endpoints ki zaroorat hai, to backend ko alag Node.js hosting par deploy karna aur frontend ke API URL ko us hosting ke URL par configure karna hoga. Isliye deployment successful hone ka matlab zaroori nahi ki backend-dependent features bhi kaam karenge.

## Repository path
Workflow mein Vite base `/cyrus-ultra-pro-real-api/` set hai. Agar repository ka naam badlo, workflow ke `--base` path ko bhi update karo.
